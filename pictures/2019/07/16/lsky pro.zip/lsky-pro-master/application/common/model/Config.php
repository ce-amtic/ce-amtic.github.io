<?php
/**
 * User: Wisp X
 * Date: 2018/9/26
 * Time: 下午4:35
 * Link: https://github.com/wisp-x
 */

namespace app\common\model;

use think\Model;

class Config extends Model
{
    protected $createTime = false;

    protected $json = ['extend'];
}