<?php
/**
 * Created by WispX.
 * User: WispX
 * Date: 2019/5/8
 * Time: 21:33
 */

return [
    // 色情图片是否直接拦截
    'intercept_salacity' => false,
];
